COL_LIST = ['Name', 'PID', 'CPU Memory (%)', 'GPU Memory (%)', 'State', 'Owner', 'Priority', 'Project']
NO_TEAM_COL_NAMES = {0:'Name', 1:'PID', 2:'CPU Mem', 3:'GPU Mem', 4:'State'}
TEAM_COL_NAMES = {0:'Name', 5:'Owner', 6:'Priority', 7:'Project'}
