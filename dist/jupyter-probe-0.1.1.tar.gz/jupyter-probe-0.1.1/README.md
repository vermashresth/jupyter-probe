# Jupyter Probe
A package to monitor, manage, declare and analyse notebook resource usage on jupyter environments
